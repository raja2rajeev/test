
package encript.cloud;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServletDataOwner extends HttpServlet{

    private static final long serialVersionUID = 1L;
    
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  

        response.setContentType("text/html");  
        PrintWriter out = response.getWriter();
        
       
        
     
        String e=request.getParameter("email");  
        String p=request.getParameter("pass"); 
        
        
        HttpSession session = request.getSession(false);
        if(session!=null)
        session.setAttribute("email", e);

        if(LoginDataOwner.validate(e, p)){  
           
            
          response.sendRedirect("http://localhost:8084/GroupEncription/data-owner/dashboard.jsp"); 
        }  
        else{  
            out.print("<p style=\"color:red\">Sorry Email or password error</p>");  
            RequestDispatcher rd=request.getRequestDispatcher("/data-owner/");  
            rd.include(request,response);  
        }  

        out.close();  
    }  
} 
