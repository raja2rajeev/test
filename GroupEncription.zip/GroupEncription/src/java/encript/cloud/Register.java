package encript.cloud;

import java.io.*;  
import java.sql.*;  
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;  
import javax.servlet.http.*;  
  
public class Register extends HttpServlet {  
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
  
response.setContentType("text/html");  
PrintWriter out = response.getWriter();  
          
String name=request.getParameter("name");  
String email=request.getParameter("email");
String pass=request.getParameter("pass");  
String dob=request.getParameter("dob"); 
String gender=request.getParameter("gender"); 
String role=request.getParameter("role");  
String address=request.getParameter("address");  
String group=request.getParameter("group");  
          
try{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kase",
            "root", "root");
    Statement st = con.createStatement();
int i = st.executeUpdate("insert into login(name, email, password,dob,gender,role, location,group_) values ('" + name + "','" + email + "','" + pass + "','" + dob + "','" + gender + "','" + role + "','" + address + "','" + group + "')");
    if (i > 0) {
        //session.setAttribute("userid", user);
        //response.sendRedirect("index.jsp");
       out.print("Registration Successfull!"+"<a href='index.jsp'>Go to Login</a>");
    } else {
        
         out.print("Registration Error");
    }  

}   catch (ClassNotFoundException ex) {  
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SQLException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    }  
  
}  
}