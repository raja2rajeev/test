package encript.cloud;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Upload_Key")
@MultipartConfig(maxFileSize = 10177215) // upload file's size up to 16MB
public class Upload_Key extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Upload_Key() {
        super();
    }

    private String dbURL = "jdbc:mysql://localhost:3306/kase";
    private String dbUser = "root";
    private String dbPass = "root";
     
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        // gets values of text fields
        
            
            String upload_by=request.getParameter("upload_by");
             String keyword=request.getParameter("keyword");
             String secret_key=request.getParameter("secret_key");
             String secret_key1=request.getParameter("secret_key1");
            String id=request.getParameter("id"); 
         
         
        Connection conn = null; // connection to the database
       
         
        try {
            
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
 
            // constructs SQL statement
            String sql = "UPDATE documents  SET  upload_by ='"+upload_by+"',keyword ='"+keyword+"',secret_key ='"+secret_key+"',secret_key1 ='"+secret_key1+"' where Doc_id='"+id+"' ";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.executeUpdate();
            
             
           
 
            
        } catch (SQLException ex) {
           // message = "ERROR: " + ex.getMessage();
        } finally {
            if (conn != null) {
                // closes the database connection
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
            // sets the message in request scope
           
             
            // forwards to the message page
            response.sendRedirect("http://localhost:8084/GroupEncription/data-owner/file_detail.jsp"); 
        }
    }
}

